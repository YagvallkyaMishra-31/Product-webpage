# Personal Portfolio

A responsive personal portfolio website built with HTML5 and CSS3.

## Project Description
This project showcases my skills, projects, and contact information. It features a modern, responsive design with a sticky navbar, hero section, skill grid, project showcase, and a contact form.

## Tech Stack
- **HTML5**: Semantic structure.
- **CSS3**: Variable-based styling, Flexbox, Grid, Animations.
- **Font Awesome**: Icons.
- **Google Fonts**: Typography (Inter).

## Features
- **Responsive Design**: Works on Mobile, Tablet, and Desktop.
- **Dark Mode Support**: Uses CSS variables for color preferences.
- **Grid & Flexbox**: Utilizes modern layout techniques.
- **Animations**: Smooth fade-ins and hover effects.
- **Validation**: HTML5 form validation.

## How to Run
1. Clone the repository.
   ```bash
   git clone <repo-url>
   ```
2. Open `index.html` in your browser.

## Screenshots
*(Add screenshots here)*

## Live Link
[GitHub Pages Link](https://yagvallkya.github.io/portfolio)
